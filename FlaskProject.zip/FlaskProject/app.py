import certifi
from flask import Flask, render_template, request, redirect
from pymongo import MongoClient
from user import User
import csv
import os


app = Flask(__name__)


# Connect to MongoDB
client = MongoClient(
    "mongodb+srv://kenaofili:zS59HojgurCT5KHC@cluster0.g5tapwu.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0",
    tls=True,
    tlsCAFile=certifi.where()
)
db = client["survey_db"]
collection = db["participants"]

@app.route("/", methods=["GET", "POST"])
def survey():
    if request.method == "POST":
        # Collect form data
        age = request.form.get("age")
        gender = request.form.get("gender")
        total_income = request.form.get("income")
        expenses = {}
        categories = ["utilities", "entertainment", "school_fees", "shopping", "healthcare"]

        for cat in categories:
            if request.form.get(cat):
                expenses[cat] = float(request.form.get(f"{cat}_amount", 0))
            else:
                expenses[cat] = 0.0

        total_expenses = sum(expenses.values())

        # Create User instance
        user = User(age=int(age), gender=gender, income=float(total_income), expenses=expenses)

        # Save to MongoDB
        collection.insert_one(user.to_dict())

        # Save to CSV
        file_exists = os.path.isfile("data.csv")
        with open("data.csv", mode="a", newline="") as file:
            writer = csv.writer(file)
            if not file_exists:
                writer.writerow(["Age", "Gender", "Income"] + [cat.capitalize() for cat in categories])
            writer.writerow([user.age, user.gender, user.income] + [user.expenses[cat] for cat in categories])

        return redirect("/")
    return render_template("index.html")


if __name__ == '__main__':
    app.run()
